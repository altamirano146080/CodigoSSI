<?php
	$cadena = file_get_contents("login.html");

	echo $cadena;
?>