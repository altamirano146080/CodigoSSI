#!/bin/bash

# Listar contenido del directorio actual
ls

# Subir un nivel en el árbol de directorios
cd ..

# Listar contenido del nuevo directorio
ls
